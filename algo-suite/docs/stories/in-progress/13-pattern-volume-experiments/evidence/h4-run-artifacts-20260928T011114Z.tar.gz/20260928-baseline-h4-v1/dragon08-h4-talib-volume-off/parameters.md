# dragon08-h4-talib-volume-off

Exploratory, previously inspected 2015 window; not confirmatory.

See provenance.json for exact windows, inputs and XML source hashes.

See source-mapping.md for every XML mapping and unsupported semantic; source-configs/ and source-xml/ preserve the original files.

```text
capital_mgmt.assumed_leverage = 30.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.atr_multiplier = 2.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.lot_notional_units = 100000.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.min_reward_risk = 2.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.min_stop_factor = 1.2  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.min_stop_pips = 5.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.pip_value_per_lot = 10.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.risk_per_trade = 0.03  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.stop_distance_source = "swing"  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.stop_loss_pips = 20.0  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.stop_loss_shrink = 0.5  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.targets = [{"at_level_ratio": 4.0, "close_fraction": 0.5}, {"at_level_ratio": 6.0, "close_fraction": 0.5}]  # dragon08-h4-talib-volume-off/config.yaml
capital_mgmt.trail_stops = [{"at_level_ratio": 2.0, "to_level_ratio": 0.1}]  # dragon08-h4-talib-volume-off/config.yaml
execution.broker_stop_level_pips = 0.0  # dragon08-h4-talib-volume-off/config.yaml
execution.close_on_veto = false  # dragon08-h4-talib-volume-off/config.yaml
execution.commission_per_lot = 0.0  # dragon08-h4-talib-volume-off/config.yaml
execution.min_hold_bars = 0  # dragon08-h4-talib-volume-off/config.yaml
execution.spread_pips = 1.0  # dragon08-h4-talib-volume-off/config.yaml
filters = ["f1_trend", "f2_indicator", "f3_pattern", "f5_risk_guard", "f6_capital_mgmt", "f7_meta_learner"]  # dragon08-h4-talib-volume-off/config.yaml
indicator.macd_hist_threshold = 0.0  # dragon08-h4-talib-volume-off/config.yaml
indicator.rsi_midline = 50.0  # dragon08-h4-talib-volume-off/config.yaml
meta_learner.families = ["trend", "indicator", "pattern"]  # dragon08-h4-talib-volume-off/config.yaml
meta_learner.label_horizon_minutes = 240  # dragon08-h4-talib-volume-off/config.yaml
meta_learner.regime_gate = false  # dragon08-h4-talib-volume-off/config.yaml
meta_learner.theta_high = 0.55  # dragon08-h4-talib-volume-off/config.yaml
meta_learner.theta_low = 0.45  # dragon08-h4-talib-volume-off/config.yaml
pattern.bearish_patterns = ["bearish_engulfing", "evening_star", "shooting_star"]  # dragon08-h4-talib-volume-off/config.yaml
pattern.bullish_patterns = ["bullish_engulfing", "hammer", "morning_star"]  # dragon08-h4-talib-volume-off/config.yaml
pattern.detector = "talib"  # dragon08-h4-talib-volume-off/config.yaml
perception_source = "ema"  # dragon08-h4-talib-volume-off/config.yaml
price_features.atr_period = 14  # dragon08-h4-talib-volume-off/config.yaml
price_features.bar_minutes = 240  # dragon08-h4-talib-volume-off/config.yaml
price_features.ema_fast = 3  # dragon08-h4-talib-volume-off/config.yaml
price_features.ema_higher_tf = 60  # dragon08-h4-talib-volume-off/config.yaml
price_features.ema_slow = 8  # dragon08-h4-talib-volume-off/config.yaml
price_features.macd_fast = 12  # dragon08-h4-talib-volume-off/config.yaml
price_features.macd_signal = 9  # dragon08-h4-talib-volume-off/config.yaml
price_features.macd_slow = 26  # dragon08-h4-talib-volume-off/config.yaml
price_features.rsi_period = 14  # dragon08-h4-talib-volume-off/config.yaml
price_features.swing_lookback_bars = 60  # dragon08-h4-talib-volume-off/config.yaml
risk_guard.daily_drawdown_limit = -0.05  # dragon08-h4-talib-volume-off/config.yaml
risk_guard.max_concurrent_trades_per_account = 2  # dragon08-h4-talib-volume-off/config.yaml
risk_guard.max_leverage = 30  # dragon08-h4-talib-volume-off/config.yaml
risk_guard.portfolio_at_risk_cap = 0.18  # dragon08-h4-talib-volume-off/config.yaml
risk_guard.weekly_drawdown_limit = -0.15  # dragon08-h4-talib-volume-off/config.yaml
schema_version = 2  # dragon08-h4-talib-volume-off/config.yaml
```

```json
{
  "schema_version": 1,
  "classification": "exploratory",
  "family": "dragon08-h4-swing-proxy",
  "symbol": "EURUSD",
  "cash": 10000,
  "broker_adapter": "oanda",
  "train_start": "2015-02-02",
  "train_end": "2015-06-30",
  "calibration_start": "2015-07-01",
  "calibration_end": "2015-07-31",
  "test_start": "2015-09-01",
  "test_end": "2015-09-30",
  "train_timeout_seconds": 7200,
  "backtest_timeout_seconds": 1800,
  "model_policy": "separate_per_variant",
  "resources": {
    "workers": 2,
    "lean_max_concurrent": 6,
    "lean_container_cpus": 4,
    "lean_container_mem_gib": 8,
    "training_numeric_threads": 4,
    "training_device": "cpu"
  },
  "mode": "baseline",
  "variants": [
    "dragon08-h4-disabled-volume-off",
    "dragon08-h4-disabled-volume-on",
    "dragon08-h4-talib-volume-off",
    "dragon08-h4-talib-volume-on"
  ]
}
```
