# Account Statement

**A/C No: results   Name: dragon08-h4-talib-volume-on / EURUSD   2015.10.01 00:00**

Period: 2015-09-01 .. 2015-09-30 UTC · Broker adapter: oanda · Starting deposit: 10,000.00 · Generated: 2026-09-28T01:04:18Z

## Closed Transactions:

| Ticket | Open Time | Type | Lots | Item | Price | S / L | T / P | Close Time | Price | Commission | R/O Swap | Trade P/L |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2015.09.17 16:00 | sell | 0.27 | EURUSD | 1.1309700000000000 | 1.1341174999999999 | 1.1178800000000002 / 1.1113850000000003 | 2015.09.17 17:55 | 1.1341200000000000 | 0.00 | 0.00 | -84.77 |
| 5 | 2015.09.17 20:00 | sell | 0.17 | EURUSD | 1.1438200000000001 | 1.1443200000000000 | 1.1413200000000001 / 1.1401200000000000 | 2015.09.17 20:46 | 1.1436700000000000 | 0.00 | 0.00 | 2.54 |
| 9 | 2015.09.18 12:00 | sell | 0.17 | EURUSD | 1.1430600000000000 | 1.1445000000000001 | 1.1367999999999996 / 1.1337199999999994 | 2015.09.18 19:10 | 1.1352599110083790 | 0.00 | 0.00 | 134.98 |
| **Total** |  |  |  |  |  |  |  |  |  | 0.00 | 0.00 | 52.75 |

Deposit/Withdrawal: 0.00    Credit Facility: 0.00    Closed Trade P/L: 52.75

_R/O Swap is 0.00 on every line: the LEAN forex model applies no rollover._

## Open Trades:

| Ticket | Open Time | Type | Lots | Item | Price | S / L | T / P | Price | Commission | R/O Swap | Trade P/L |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 13 | 2015.09.21 12:00 | sell | 0.29 | EURUSD | 1.1251400000000000 | 1.1355425000000001 | 1.0830299999999997 / 1.0620249999999996 | 1.1170549480873375 | 0.00 | 0.00 | 233.96 |
| **Total** |  |  |  |  |  |  |  |  | 0.00 | 0.00 | 233.96 |

Floating P/L: 233.96

## Working Orders:

| Ticket | Open Time | Type | Lots | Item | Price | S / L | T / P | Market Price |
|---|---|---|---|---|---|---|---|---|
| 14 | 2015.09.21 12:00 | buy | 0.29 | EURUSD | 1.1355400000000000 | — | — | 1.1170549480873375 |
| 15 | 2015.09.21 12:00 | buy | 0.14 | EURUSD | 1.0830299999999999 | — | — | 1.1170549480873375 |
| 16 | 2015.09.21 12:00 | buy | 0.14 | EURUSD | 1.0620200000000000 | — | — | 1.1170549480873375 |

## A/C Summary:

|  |  |  |  |
|---|---|---|---|
| Previous Ledger Balance | 10,000.00 | Floating P/L | 233.96 |
| Closed Trade P/L | 52.75 | Total Credit Facility | 0.00 |
| Deposit/Withdrawal | 0.00 | Equity | 10,286.71 |
| Balance | 10,052.75 | Margin Requirement | 647.65 |
|  |  | Available Margin | 9,639.06 |

_Equity (engine-reported): 10,287.14 (LEAN's runtimeStatistics Equity, for reconciliation)._

## Performance

| Metric | Value |
|---|---|
| Net profit | 2.871% |
| Max drawdown | 5.100% |
| Sharpe ratio | 2.11 |
| Win rate | 75% |
| Average win | 0.46% |
| Average loss | -0.85% |
| Total orders | 16 |
| Trades | 3 |
| Median holding (minutes) | 115.0 |

## Parameters

| Parameter | Value | Source |
|---|---|---|
| capital_mgmt.assumed_leverage | `30.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.atr_multiplier | `2.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.lot_notional_units | `100000.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.min_reward_risk | `2.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.min_stop_factor | `1.2` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.min_stop_pips | `5.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.pip_value_per_lot | `10.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.risk_per_trade | `0.03` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.stop_distance_source | `"swing"` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.stop_loss_pips | `20.0` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.stop_loss_shrink | `0.5` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.targets | `[{"at_level_ratio": 4.0, "close_fraction": 0.5}, {"at_level_ratio": 6.0, "close_fraction": 0.5}]` | dragon08-h4-talib-volume-on/config.yaml |
| capital_mgmt.trail_stops | `[{"at_level_ratio": 2.0, "to_level_ratio": 0.1}]` | dragon08-h4-talib-volume-on/config.yaml |
| execution.broker_stop_level_pips | `0.0` | dragon08-h4-talib-volume-on/config.yaml |
| execution.close_on_veto | `false` | dragon08-h4-talib-volume-on/config.yaml |
| execution.commission_per_lot | `0.0` | dragon08-h4-talib-volume-on/config.yaml |
| execution.min_hold_bars | `0` | dragon08-h4-talib-volume-on/config.yaml |
| execution.spread_pips | `1.0` | dragon08-h4-talib-volume-on/config.yaml |
| filters | `["f1_trend", "f2_indicator", "f3_pattern", "volume_strength", "f5_risk_guard", "f6_capital_mgmt", "f7_meta_learner"]` | dragon08-h4-talib-volume-on/config.yaml |
| indicator.macd_hist_threshold | `0.0` | dragon08-h4-talib-volume-on/config.yaml |
| indicator.rsi_midline | `50.0` | dragon08-h4-talib-volume-on/config.yaml |
| meta_learner.families | `["trend", "indicator", "pattern"]` | dragon08-h4-talib-volume-on/config.yaml |
| meta_learner.label_horizon_minutes | `240` | dragon08-h4-talib-volume-on/config.yaml |
| meta_learner.regime_gate | `false` | dragon08-h4-talib-volume-on/config.yaml |
| meta_learner.theta_high | `0.55` | dragon08-h4-talib-volume-on/config.yaml |
| meta_learner.theta_low | `0.45` | dragon08-h4-talib-volume-on/config.yaml |
| pattern.bearish_patterns | `["bearish_engulfing", "evening_star", "shooting_star"]` | dragon08-h4-talib-volume-on/config.yaml |
| pattern.bullish_patterns | `["bullish_engulfing", "hammer", "morning_star"]` | dragon08-h4-talib-volume-on/config.yaml |
| pattern.detector | `"talib"` | dragon08-h4-talib-volume-on/config.yaml |
| perception_source | `"ema"` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.atr_period | `14` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.bar_minutes | `240` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.ema_fast | `3` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.ema_higher_tf | `60` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.ema_slow | `8` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.macd_fast | `12` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.macd_signal | `9` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.macd_slow | `26` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.rsi_period | `14` | dragon08-h4-talib-volume-on/config.yaml |
| price_features.swing_lookback_bars | `60` | dragon08-h4-talib-volume-on/config.yaml |
| risk_guard.daily_drawdown_limit | `-0.05` | dragon08-h4-talib-volume-on/config.yaml |
| risk_guard.max_concurrent_trades_per_account | `2` | dragon08-h4-talib-volume-on/config.yaml |
| risk_guard.max_leverage | `30` | dragon08-h4-talib-volume-on/config.yaml |
| risk_guard.portfolio_at_risk_cap | `0.18` | dragon08-h4-talib-volume-on/config.yaml |
| risk_guard.weekly_drawdown_limit | `-0.15` | dragon08-h4-talib-volume-on/config.yaml |
| schema_version | `2` | dragon08-h4-talib-volume-on/config.yaml |
| volume_strength.lookback | `20` | dragon08-h4-talib-volume-on/config.yaml |
| volume_strength.min_relative_activity | `1.0` | dragon08-h4-talib-volume-on/config.yaml |
| cash | `10000` | --param |

![Equity and drawdown](equity.png)
