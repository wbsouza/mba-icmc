# Account Statement

**A/C No: results   Name: dragon08-h4-hybrid-talib-volume-off / EURUSD   2015.10.01 00:00**

Period: 2015-09-01 .. 2015-09-30 UTC · Broker adapter: oanda · Starting deposit: 10,000.00 · Generated: 2026-09-28T01:10:10Z

## Closed Transactions:

| Ticket | Open Time | Type | Lots | Item | Price | S / L | T / P | Close Time | Price | Commission | R/O Swap | Trade P/L |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2015.09.17 04:00 | sell | 0.28 | EURUSD | 1.1299100000000000 | 1.1335875000000000 | 1.1147000000000000 / 1.1071450000000000 | 2015.09.17 08:04 | 1.1335900000000001 | 0.00 | 0.00 | -103.98 |
| 5 | 2015.09.17 12:00 | sell | 0.26 | EURUSD | 1.1316400000000000 | 1.1344525000000001 | 1.1198900000000001 / 1.1140650000000001 | 2015.09.17 17:55 | 1.1344500000000000 | 0.00 | 0.00 | -72.65 |
| 9 | 2015.09.17 20:00 | sell | 0.17 | EURUSD | 1.1438200000000001 | 1.1443200000000000 | 1.1413200000000001 / 1.1401200000000000 | 2015.09.17 20:46 | 1.1436700000000000 | 0.00 | 0.00 | 2.52 |
| 13 | 2015.09.18 04:00 | sell | 0.19 | EURUSD | 1.1395299999999999 | 1.1418074999999999 | 1.1299200000000003 / 1.1251650000000004 | 2015.09.18 07:16 | 1.1418800000000000 | 0.00 | 0.00 | -44.91 |
| 17 | 2015.09.18 08:00 | sell | 0.17 | EURUSD | 1.1431800000000001 | 1.1436800000000000 | 1.1406800000000001 / 1.1394800000000000 | 2015.09.18 08:02 | 1.1436800000000000 | 0.00 | 0.00 | -8.50 |
| 21 | 2015.09.18 12:00 | sell | 0.17 | EURUSD | 1.1430600000000000 | 1.1445000000000001 | 1.1367999999999996 / 1.1337199999999994 | 2015.09.18 19:10 | 1.1352599999999999 | 0.00 | 0.00 | 133.01 |
| **Total** |  |  |  |  |  |  |  |  |  | 0.00 | 0.00 | -94.51 |

Deposit/Withdrawal: 0.00    Credit Facility: 0.00    Closed Trade P/L: -94.51

_R/O Swap is 0.00 on every line: the LEAN forex model applies no rollover._

## Open Trades:

| Ticket | Open Time | Type | Lots | Item | Price | S / L | T / P | Price | Commission | R/O Swap | Trade P/L |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 25 | 2015.09.21 12:00 | sell | 0.29 | EURUSD | 1.1251400000000000 | 1.1355425000000001 | 1.0830299999999997 / 1.0620249999999996 | 1.1170548904291815 | 0.00 | 0.00 | 230.53 |
| **Total** |  |  |  |  |  |  |  |  | 0.00 | 0.00 | 230.53 |

Floating P/L: 230.53

## Working Orders:

| Ticket | Open Time | Type | Lots | Item | Price | S / L | T / P | Market Price |
|---|---|---|---|---|---|---|---|---|
| 26 | 2015.09.21 12:00 | buy | 0.29 | EURUSD | 1.1355400000000000 | — | — | 1.1170548904291815 |
| 27 | 2015.09.21 12:00 | buy | 0.14 | EURUSD | 1.0830299999999999 | — | — | 1.1170548904291815 |
| 28 | 2015.09.21 12:00 | buy | 0.14 | EURUSD | 1.0620200000000000 | — | — | 1.1170548904291815 |

## A/C Summary:

|  |  |  |  |
|---|---|---|---|
| Previous Ledger Balance | 10,000.00 | Floating P/L | 230.53 |
| Closed Trade P/L | -94.51 | Total Credit Facility | 0.00 |
| Deposit/Withdrawal | 0.00 | Equity | 10,136.02 |
| Balance | 9,905.49 | Margin Requirement | 638.16 |
|  |  | Available Margin | 9,497.86 |

_Equity (engine-reported): 10,136.43 (LEAN's runtimeStatistics Equity, for reconciliation)._

## Performance

| Metric | Value |
|---|---|
| Net profit | 1.364% |
| Max drawdown | 5.100% |
| Sharpe ratio | 0.924 |
| Win rate | 43% |
| Average win | 0.46% |
| Average loss | -0.58% |
| Total orders | 28 |
| Trades | 6 |
| Median holding (minutes) | 220.0 |

## Parameters

| Parameter | Value | Source |
|---|---|---|
| capital_mgmt.assumed_leverage | `30.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.atr_multiplier | `2.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.lot_notional_units | `100000.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.min_reward_risk | `2.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.min_stop_factor | `1.2` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.min_stop_pips | `5.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.pip_value_per_lot | `10.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.risk_per_trade | `0.03` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.stop_distance_source | `"swing"` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.stop_loss_pips | `20.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.stop_loss_shrink | `0.5` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.targets | `[{"at_level_ratio": 4.0, "close_fraction": 0.5}, {"at_level_ratio": 6.0, "close_fraction": 0.5}]` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| capital_mgmt.trail_stops | `[{"at_level_ratio": 2.0, "to_level_ratio": 0.1}]` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| execution.broker_stop_level_pips | `0.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| execution.close_on_veto | `false` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| execution.commission_per_lot | `0.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| execution.min_hold_bars | `0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| execution.spread_pips | `1.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| filters | `["f1_trend", "f2_indicator", "f3_pattern", "f4_news_context", "f5_risk_guard", "f6_capital_mgmt", "f7_meta_learner"]` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| indicator.macd_hist_threshold | `0.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| indicator.rsi_midline | `50.0` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| meta_learner.families | `["trend", "indicator", "pattern", "news"]` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| meta_learner.label_horizon_minutes | `240` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| meta_learner.regime_gate | `false` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| meta_learner.theta_high | `0.55` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| meta_learner.theta_low | `0.45` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| news_context.event_intensity_veto_threshold | `-0.5` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| news_context.sentiment_direction_threshold | `0.15` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| pattern.bearish_patterns | `["bearish_engulfing", "evening_star", "shooting_star"]` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| pattern.bullish_patterns | `["bullish_engulfing", "hammer", "morning_star"]` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| pattern.detector | `"talib"` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| perception_source | `"ema"` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.atr_period | `14` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.bar_minutes | `240` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.ema_fast | `3` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.ema_higher_tf | `60` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.ema_slow | `8` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.macd_fast | `12` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.macd_signal | `9` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.macd_slow | `26` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.rsi_period | `14` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| price_features.swing_lookback_bars | `60` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| risk_guard.daily_drawdown_limit | `-0.05` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| risk_guard.max_concurrent_trades_per_account | `2` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| risk_guard.max_leverage | `30` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| risk_guard.portfolio_at_risk_cap | `0.18` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| risk_guard.weekly_drawdown_limit | `-0.15` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| schema_version | `2` | dragon08-h4-hybrid-talib-volume-off/config.yaml |
| cash | `10000` | --param |

![Equity and drawdown](equity.png)
